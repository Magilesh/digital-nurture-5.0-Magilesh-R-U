package com.cognizant.Spring_Learn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
